## Task
Piece together the assembly lines from all the qr-codes and run the program

Flag: `TG19{qr_codes_and_assembly_is_cool}`
