## Task
Puzzle together the shuffling qr-code in the order specified by the numbers

Flag: `TG19{good_thing_we_called_ghostbusters}`

How to run:

```bash
watch -t -n0.1 "cat code.qr | shuf"
```
